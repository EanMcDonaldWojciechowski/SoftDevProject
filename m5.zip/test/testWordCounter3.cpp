//lang::CwC
// #include "../src/network/KVStore.h"
#include "../src/dataframe/modified_dataframe.h"

int main(int argc, char** argv) {
  size_t nodeIndex = 2;
  
  WordCount *wordCounter = new WordCount(nodeIndex);

  std::cout << "COMPLETED" << "\n";
}
